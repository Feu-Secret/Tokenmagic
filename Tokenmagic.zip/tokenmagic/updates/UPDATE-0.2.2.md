# Token Magic FX - Update v0.2.2-alpha

*Added :*
- You can now add FX on drawings. the operating principles are the same as with tokens and tiles.
- Some optimizations in the shaders