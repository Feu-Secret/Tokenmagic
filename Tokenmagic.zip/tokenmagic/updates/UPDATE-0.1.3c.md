# Token Magic FX - Update v0.1.3c-alpha

*Fixed issues :*
- Freezing when a scene is updated
- Crash when a scene with animated tokens or tiles is deleted (with active players/GM in the scene)

