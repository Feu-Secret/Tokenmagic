# Token Magic FX - Update v0.2.2b-alpha

*Fixed issues :*
- Compatibility problem with furnace module drawings tools.