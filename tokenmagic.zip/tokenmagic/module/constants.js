export const defaultOpacity = 0.5;
export const emptyPreset = 'NOFX';
export const autoMinRank = 10000;