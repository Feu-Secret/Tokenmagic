# Token Magic FX - Update v0.1.3d-alpha

*Fixed regression :*
- autoDestroy and autoDisable properties not working properly.

