# Tokenmagic
A Foundry VTT module that allows you to add graphic effects to tokens and tiles.
