# Token Magic FX - Update v0.1.3b-alpha

*Fixed issues :*
- Animations freezing with target-enhancements module

