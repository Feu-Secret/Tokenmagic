export const defaultOpacity = 0.5;
export const emptyPreset = 'NOFX';