# Token Magic FX - Update v0.4.4-alpha (Mess edition PART I)

*News :*
- Integration of Mess Moerill's Supersuit(e) (for templates) part I :
  - Video support in templates :
    - You can set webm, mp4, etc. as video texture.
    - You can define videos in the automatic spell templates options (for dd5 only).
  - Texture autoresize :
    - The choosen texture is resized to fit the template.
- TMFX now supports the Spanish language! 

Many thanks to Lozalojo (Spanish translation) and Moerill (video) for this release!

*Fixed Issues :*
- Template effect tint was badly formatted during an automatic template creation.






